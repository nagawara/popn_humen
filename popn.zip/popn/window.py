import cv2
import numpy as np
from matplotlib import pyplot as plt

img_rgb = cv2.imread('hdrock-e1.png')
img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
templateaka = cv2.imread('aka.png',0)
templateshiro = cv2.imread('shiro.bmp',0)
templateao = cv2.imread('ao.bmp',0)
templatemidori = cv2.imread('midori.bmp',0)
templateki = cv2.imread('ki.bmp',0)

img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)

#Adaptive Gaussian Thresholding
img_n = cv2.adaptiveThreshold(img_gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,11,2)



edges = cv2.Canny(img_n,50,150,apertureSize = 3)

oi = 0
aka = []
ao = []
ki = []
midori = []
shiro = []

w0, h0 = templateaka.shape[::-1]
w1, h1 = templateshiro.shape[::-1]
w2, h2 = templateao.shape[::-1]
w3, h3 = templatemidori.shape[::-1]
w4, h4 = templateki.shape[::-1]


threshold = 0.99


res = cv2.matchTemplate(img_gray,templateaka,cv2.TM_CCOEFF_NORMED)
loc = np.where( res >= threshold)
aka = loc
res = cv2.matchTemplate(img_gray,templateao,cv2.TM_CCOEFF_NORMED)
loc = np.where( res >= threshold)
ao = loc
res = cv2.matchTemplate(img_gray,templatemidori,cv2.TM_CCOEFF_NORMED)
loc = np.where( res >= threshold)
midori = loc
res = cv2.matchTemplate(img_gray,templateki,cv2.TM_CCOEFF_NORMED)
loc = np.where( res >= threshold)
ki = loc
res = cv2.matchTemplate(img_gray,templateshiro,cv2.TM_CCOEFF_NORMED)
loc = np.where( res >= threshold)
shiro = loc



minLineLength = 100
maxLineGap = 10
lines = cv2.HoughLinesP(edges,1,np.pi/180,100,minLineLength,maxLineGap)
for x1,y1,x2,y2 in lines[0]:
    cv2.line(img_rgb,(x1,y1),(x2,y2),(0,255,0),1)


print(aka)
print(ao)

for pt1 in zip(*aka[::-1]):
	for pt2  in zip(*ao[::-1]):
		if pt1[1] < pt2[1]+5 and pt1[1] > pt2[1]-5 and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 5000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)
for pt1 in zip(*aka[::-1]):
	for pt2  in zip(*ki[::-1]):
		if pt1[1] < pt2[1]+5 and pt1[1] > pt2[1]-5 and  (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 5000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)
for pt1 in zip(*aka[::-1]):
	for pt2  in zip(*shiro[::-1]):
		if pt1[1] < pt2[1]+5 and pt1[1] > pt2[1]-5 and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 5000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)
for pt1 in zip(*aka[::-1]):
	for pt2  in zip(*midori[::-1]):
		if pt1[1] < pt2[1]+5 and pt1[1] > pt2[1]-5 and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 5000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)
for pt1 in zip(*ao[::-1]):
	for pt2  in zip(*ki[::-1]):
		if pt1[1] < pt2[1]+5 and pt1[1] > pt2[1]-5 and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 5000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)
for pt1 in zip(*ao[::-1]):
	for pt2  in zip(*midori[::-1]):
		if pt1[1] < pt2[1]+5 and pt1[1] > pt2[1]-5 and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 2000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)
for pt1 in zip(*ao[::-1]):
	for pt2  in zip(*shiro[::-1]):
		if pt1[1] == pt2[1] and pt1[0] != pt2[0] and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 4500:
			for x1,y1,x2,y2 in lines[0]:
				if y1+h0/2 >= pt1[1] and y1-h0/2 <= pt1[1] :
					if((pt1[0]-pt2[0])*(pt1[0]-pt2[0])<(x1-x2)*(x1-x2)):
						oi = 1
			   		if(oi == 1):			
				   		if(pt1[0]>pt2[0]):
				   			cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,255), 2)
			   			else:
							cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,255), 2)
				oi = 0
for pt1 in zip(*ki[::-1]):
	for pt2  in zip(*midori[::-1]):
		if pt1[1] < pt2[1]+5 and pt1[1] > pt2[1]-5 and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 2000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)
for pt1 in zip(*ki[::-1]):
	for pt2  in zip(*shiro[::-1]):
		if pt1[1] < pt2[1]+5 and pt1[1] > pt2[1]-5 and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 1000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)
for pt1 in zip(*midori[::-1]):
	for pt2  in zip(*shiro[::-1]):
		if pt1[1] < pt2[1]+5 and pt1[1] > pt2[1]-5 and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 1000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)

for pt1 in zip(*ao[::-1]):
	for pt2  in zip(*ao[::-1]):
		if pt1[1] == pt2[1] and pt1[0] != pt2[0] and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 2000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)

for pt1 in zip(*midori[::-1]):
	for pt2  in zip(*midori[::-1]):
		if pt1[1] == pt2[1] and pt1[0] != pt2[0] and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 2000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)

for pt1 in zip(*shiro[::-1]):
	for pt2  in zip(*shiro[::-1]):
		if pt1[1] == pt2[1] and pt1[0] != pt2[0] and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 12000:
			for x1,y1,x2,y2 in lines[0]:
				if y1+h0 > pt1[1] and y1-h0 < pt1[1] :
					if(pt1[0]>pt2[0]):
						for i   in range(pt2[0],pt1[0]):
							if(i > x1 and i < x2):
								oi = oi + 1
			   		else:
						for i in range(pt1[0],pt2[0]):
							if(i < x1 and i > x2):
								oi = 1 + oi
					if(oi >=10):			
				   		cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (255,0,0), 3)
					oi = 0

for pt1 in zip(*ki[::-1]):
	for pt2  in zip(*ki[::-1]):
		if pt1[1] == pt2[1] and pt1[0] != pt2[0] and (pt1[0] - pt2[0])*(pt1[0] - pt2[0]) < 2000:
			   if(pt1[0]>pt2[0]):
				   cv2.rectangle(img_rgb, pt2, (pt1[0] + w0, pt1[1] + h0), (0,0,0), 2)
			   else:
				   cv2.rectangle(img_rgb, pt1, (pt2[0] + w0, pt2[1] + h0), (0,0,0), 2)





cv2.imwrite('res1.png',img_n)

cv2.imwrite('res.png',img_rgb)
